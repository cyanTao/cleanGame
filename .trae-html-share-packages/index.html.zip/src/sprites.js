/* 素材管理：加载 AI 生成图片 + 蓝幕抠像去背 + 统一绘制 */
(function (root) {
  'use strict';
  const PVZ = root.PVZ = root.PVZ || {};
  const P = PVZ.platform;

  const sprites = {};   // name -> { canvas, w, h, ready }
  let loading = false;

  /* 蓝幕抠像：把接近纯蓝的背景像素变为透明 */
  function chromaKey(img, opts) {
    const w = img.width, h = img.height;
    const c = P.createCanvas();
    c.width = w; c.height = h;
    const ctx = P.ctx2d(c);
    ctx.drawImage(img, 0, 0);
    let data;
    try {
      data = ctx.getImageData(0, 0, w, h);
    } catch (e) {
      // 取不到像素（极端环境）则直接返回原图
      return c;
    }
    const px = data.data;
    const tol = (opts && opts.tol) || 0.55;      // 蓝色主导阈值
    const edge = (opts && opts.edge) || 90;      // 边缘羽化范围
    for (let i = 0; i < px.length; i += 4) {
      const r = px[i], g = px[i + 1], b = px[i + 2];
      if (b > 60 && b > r + 40 && b > g + 40) {
        // 蓝色主导程度
        const dominance = (b - Math.max(r, g)) / 255;
        if (dominance > tol) {
          px[i + 3] = 0; // 完全背景
        } else if (dominance > tol * 0.55 && b > edge) {
          px[i + 3] = Math.min(px[i + 3], 120); // 半透明过渡
        }
      }
    }
    ctx.putImageData(data, 0, 0);
    return c;
  }

  /* 缩放到目标尺寸（减小内存与包体渲染开销） */
  function scaleTo(srcCanvas, size) {
    if (srcCanvas.width <= size && srcCanvas.height <= size) return srcCanvas;
    const ratio = Math.min(size / srcCanvas.width, size / srcCanvas.height);
    const w = Math.round(srcCanvas.width * ratio);
    const h = Math.round(srcCanvas.height * ratio);
    const c = P.createCanvas();
    c.width = w; c.height = h;
    const ctx = P.ctx2d(c);
    ctx.drawImage(srcCanvas, 0, 0, w, h);
    return c;
  }

  const MANIFEST = [
    // 角色（蓝幕抠像 + 缩放）
    { name: 'sunflower',   src: 'assets/plants/sunflower.png',   chroma: true, size: 360 },
    { name: 'peashooter',  src: 'assets/plants/peashooter.png',  chroma: true, size: 360 },
    { name: 'wallnut',     src: 'assets/plants/wallnut.png',     chroma: true, size: 360 },
    { name: 'snowpea',     src: 'assets/plants/snowpea.png',     chroma: true, size: 360 },
    { name: 'repeater',    src: 'assets/plants/repeater.png',    chroma: true, size: 360 },
    { name: 'cherrybomb',  src: 'assets/plants/cherrybomb.png',  chroma: true, size: 360 },
    { name: 'z_normal',    src: 'assets/zombies/normal.png',     chroma: true, size: 360 },
    { name: 'z_conehead',  src: 'assets/zombies/conehead.png',   chroma: true, size: 360 },
    { name: 'z_buckethead',src: 'assets/zombies/buckethead.png', chroma: true, size: 360 },
    { name: 'z_polevault', src: 'assets/zombies/polevault.png',  chroma: true, size: 360 },
    { name: 'z_runner',    src: 'assets/zombies/runner.png',     chroma: true, size: 360 },
    // 背景（直接使用）
    { name: 'bg_lawn',     src: 'assets/bg/lawn.png',            chroma: false }
  ];

  function loadAll(onProgress) {
    if (loading) return Promise.resolve();
    loading = true;
    let done = 0;
    const tasks = MANIFEST.map(function (item) {
      return P.loadImage(item.src).then(function (img) {
        let c = item.chroma ? chromaKey(img, item) : img;
        if (item.size) c = scaleTo(c, item.size);
        sprites[item.name] = { canvas: c, w: c.width, h: c.height, ready: true };
        done++;
        if (onProgress) onProgress(done / MANIFEST.length);
      }).catch(function () {
        // 素材缺失时记录空占位，游戏仍可运行（绘制时用圆形占位）
        sprites[item.name] = { canvas: null, w: 0, h: 0, ready: false };
        done++;
        if (onProgress) onProgress(done / MANIFEST.length);
      });
    });
    return Promise.all(tasks);
  }

  function get(name) {
    return sprites[name] || null;
  }

  /* 按中心点 + 目标尺寸绘制（keepAspect 保持比例） */
  function draw(ctx, name, cx, cy, w, h, rot) {
    const s = get(name);
    if (!s || !s.ready || !s.canvas) {
      // 占位绘制
      ctx.save();
      ctx.fillStyle = 'rgba(80,120,60,0.8)';
      ctx.strokeStyle = 'rgba(30,60,30,0.9)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.ellipse(cx, cy, w / 2, h / 2, 0, 0, Math.PI * 2);
      ctx.fill(); ctx.stroke();
      ctx.restore();
      return;
    }
    ctx.save();
    ctx.translate(cx, cy);
    if (rot) ctx.rotate(rot);
    ctx.drawImage(s.canvas, -w / 2, -h / 2, w, h);
    ctx.restore();
  }

  function drawFlip(ctx, name, cx, cy, w, h) {
    const s = get(name);
    if (!s || !s.ready || !s.canvas) { draw(ctx, name, cx, cy, w, h); return; }
    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(-1, 1); // 水平翻转（僵尸素材默认面向左则不用，此处供统一处理）
    ctx.drawImage(s.canvas, -w / 2, -h / 2, w, h);
    ctx.restore();
  }

  PVZ.sprites = {
    MANIFEST: MANIFEST,
    loadAll: loadAll,
    get: get,
    draw: draw,
    drawFlip: drawFlip
  };
})(typeof globalThis !== 'undefined' ? globalThis : (typeof GameGlobal !== 'undefined' ? GameGlobal : this));
